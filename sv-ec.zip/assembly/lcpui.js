const ui = {
    input_dy(){
        let input = {
           tag:'input',
           type:'text',
           placeholder:'搜索你感兴趣的内容'
        }
        let right_img = {
           tag:'img',
           src:'./images/search.svg'
        }
        let right_text = {
           tag:'span',
           text:'搜索'
        }
        let right = {
           tag:'div',
           children:[
               right_img,right_text
           ]
        }
        let box = {
           tag:'div',
           children:[
               input,right
           ],
           css:`{lcpid}{
               width:450px;
               height:36px;
               display:flex;
               border:2px solid #fff;
               border-radius:10px;
               overflow:hidden;
               transform:translateX(50px);
           }
           {lcpid}>input{
               flex-grow:1;
               padding:8px 12px;
               border:0;
               outline:none;
               height:100%;
               background-color:transparent;
               box-sizing:border-box;
               width:100%;
               color:#fff;
               font-size:14px;
           }
           {lcpid}>div{
               width:90px;
               height:100%;
               display:flex;
               justify-content:center;
               align-items:center;
               cursor:pointer;
               background-color:#fff;
           }
           {lcpid}>div:hover{
               opacity:.9;
           }
           {lcpid}>div>img{
               fill:#fff;
           }
           {lcpid}>div>span{
               color:#161823;
               margin-left:5px;
               font-size:15px;
           }
           `
        }
        return box;
   },
    lcpjs_img(){
        let img = {
            tag:'img',
            src:'./logo.svg',
            style:{
                width:'40px',
                height:'40px'
            }
        }
        return img;
    },
    login_btn(){
        let img = {
            tag:'img',
            src:'./images/person.svg'
        }
        let btn = {
            tag:'div',
            children:[
                img,{
                    tag:'span',
                    text:'登录'
                }
            ],
            css:`{lcpid}{
                width:90px;
                height:38px;
                border-radius:10px;
                background-color:#fe2c55;
                color:#fff;
                display:flex;
                align-items:center;
                justify-content:center;
                cursor:pointer;
                font-size:14px;
            }
            {lcpid}:hover{
                opacity:.9;
            }
            {lcpid}>img{
                margin-right:5px;
            }`
        }
        return btn;
    },
    svec_head(){
        let head_left = {
            tag:'div',
            children:[
               ui.lcpjs_img(),
               {tag:'span',text:'短视频电商',style:{color:'#fff','font-size':'18px','margin-left':'5px'}}
            ],
            style:{
               display:'flex',
               'align-items':'center'
            }
         }
         let contribute = {
            tag:'div',
            css:`{lcpid}{
                display:flex;
                flex-direction:column;
                align-items:center;
                justify-content:center;
                margin-right:20px;
                cursor:pointer;
                opacity:.7;
            }
            {lcpid}:hover{
                opacity:1;
            }
            {lcpid}>span{
                color:#ffffffe6;
                font-size:11px;
                margin-top:2px;
            }`,
            children:[
                {tag:'img',src:'./images/contribute.svg'},
                {tag:'span',text:'投稿'}
            ]
         }
         let private = {
            tag:'div',
            css:`{lcpid}{
                display:flex;
                flex-direction:column;
                align-items:center;
                justify-content:center;
                margin-right:20px;
                cursor:pointer;
                opacity:.7;
            }
            {lcpid}:hover{
                opacity:1;
            }
            {lcpid}>span{
                color:#ffffffe6;
                font-size:11px;
                margin-top:2px;
            }`,
            children:[
                {tag:'img',src:'./images/private.svg'},
                {tag:'span',text:'私信'}
            ]
         }
         let inform = {
            tag:'div',
            css:`{lcpid}{
                display:flex;
                flex-direction:column;
                align-items:center;
                justify-content:center;
                margin-right:20px;
                cursor:pointer;
                opacity:.7;
            }
            {lcpid}:hover{
                opacity:1;
            }
            {lcpid}>span{
                color:#ffffffe6;
                font-size:11px;
                margin-top:2px;
            }`,
            children:[
                {tag:'img',src:'./images/inform.svg'},
                {tag:'span',text:'通知'}
            ]
         }
         let head_right = {
            tag:'div',
            css:`{lcpid}{
                display:flex;
                align-items:center;
            }`,
            children:[
                inform,
                private,
                contribute,
                ui.login_btn()
            ]
         }
         
       return {
            tag:'div',
            children:[
                head_left,
                ui.input_dy(),
                head_right
            ],
            css:`
            {lcpid}{
               height:4.8rem;
               background-color:var(--bgcolor);
               display:flex;
               justify-content:space-between;
               align-items:center;
               padding:0 1rem;
            }`
        }
    },
    svec_nav(){
        let img = {
            tag:'div',
            style:{
                'background-position':"{{index == 4 ? '96' : -48*index}}px 0px"
            }
        }
        let nav_btn = {
            tag:'div',
            for:'nav_list',
            'v-key':'{{index}}',
            class:{nav_box:true,this:'nav_index == index'},
            children:[
               img,{tag:'span',text:'{{value}}'}
            ],
            onclick(e){
               let index = e.target.getAttribute('v-key');
               if(index == null){
                 index = e.target.parentElement.getAttribute('v-key');
               }
               let forbear = this.forbear();
               let data = forbear.data;
               console.log(index)
               if(index == 0){
                 history.pushState({path:'/index',title:'111'},null,'/index');
               }else if(index == 1){
                 history.pushState({path:'/two',title:'111'},null,'/two')
               }else if(index == 2){
                 history.pushState({path:'/three',title:'111'},null,'/three')
               }
               data.nav_index = index;
            }
        }
        let br = {
            tag:'div',
            style:{
                height:'1px',
                backgroundColor:'#393939',
                width:'100%',
                'margin':'10px 0'
            }
        }
        let img1 = {
            tag:'img',
            src:'./images/order.svg'
        }
        let img2 = {
            tag:'img',
            src:'./images/cart.svg'
        }
        let menu_box = {
            tag:'div',
            class:{nav_box:true},
            children:[
                img1,{tag:'span',text:'订单'}
             ]
        }
        let menu_box2 = {
            tag:'div',
            class:{nav_box:true},
            children:[
                img2,{tag:'span',text:'购物车'}
             ]
        }
        let menu = {
            tag:'div',
            style:{
                width:'6rem',
                display:'flex',
                'flex-direction':'column',
                'align-items':'center'
            },
            children:[
                br,
                menu_box,
                menu_box2
            ]
        }
        return {
            tag:'div',
            css:`{lcpid}{
                width:11rem;
                display:flex;
                flex-direction:column;
                align-items:center;
                padding-top:10px;
                flex-shrink:0;
            }`,
            children:[
                nav_btn,
                menu
            ]
        }
    },
    svec_content(){
        return {
            tag:'div',
            css:`{lcpid}{
                flex-grow:1;
                height:100%;
                margin:0 15px 0 15px;
                overflow:hidden;
            }`
        }
    },
    commodity(){
        let heart_ = {
            tag:'img',
            src:'./images/heart.svg',
            style:{
                width:'13px',
                height:'13px',
                'margin-top':'3px'
            }
        }
        let heart = {
            tag:'div',
            css:`{lcpid}{
                position:absolute;
                bottom:10px;
                left:10px; 
                display:flex;
                align-items:center;
            }
            {lcpid}>span{
                font-size:14px;
                color:#fff;
                text-shadow:0 0 2px rgba(0,0,0,0.15);
                margin-left:4px;
                display:flex;
                align-items:center;
            }`,
            children:[
                heart_,
                {
                    tag:'span',
                    text:'{{value.heart}}'
                }
            ]
        }
        let length = {
            tag:'div',
            text:'{{value.duration}}',
            css:`{lcpid}{
                position:absolute;
                width:50px;
                height:20px;
                background-color:rgba(0,0,0,0.8);
                bottom:10px;
                right:10px;
                color:#eee;
                border-radius:15px;
                display:flex;
                align-items:center;
                justify-content:center;
                font-size:14px;
            }`
        }
        let img = {
            tag:'div',
            children:[
                {
                    tag:'img',
                    src:'{{value.src}}',
                    loading:'lazy',
                    alt:'加载失败'
                },
                heart,length
            ],
            css:`{lcpid}{
                position:relative;
            }
            {lcpid}>img{
                transition:transform .3s;
            }
            {lcpid}>img:hover{
                transform:scale(1.2);
            }`
        }
        let text = {
            tag:'div',
            children:[
                {
                    tag:'div',
                    text:'{{value.text}}'
                },
                {
                    tag:'div',
                    text:'{{value.anthor}}'
                }
            ]
        }
        return {
          tag:'div',
          children:[
            img,text
          ],
          css:`{lcpid}{
            width:calc(25% - 16px);
            max-width:276px;
            height:320px;
            cursor:pointer;
            background-color:var(--commodity_color);
            border-radius:10px;
            overflow:hidden;
            box-shadow:0 0 2px rgba(0,0,0,0.05);
            display:flex;
            flex-direction:column;
          }
          {lcpid}>div:nth-child(1){
            flex-grow:1;
            overflow:hidden;
          }
          {lcpid}>div:nth-child(1)>img{
            width:100%;
            height:100%;
            background-size:cover;
            border:0;
          }
          {lcpid}>div:nth-child(2){
            height:80px;
            padding:10px;
            display:flex;
            flex-direction:column;
            flex-shrink:0;
          }
          {lcpid}>div:nth-child(2)>div:nth-child(1){
            flex-grow:1;
            color:#eee;
            overflow:hidden;
            word-break: break-all;
            text-overflow: ellipsis;
            font-size:13px;
          }
          {lcpid}>div:nth-child(2)>div:nth-child(2){
            height:20px;
            color:#888;
            flex-shrink:0;
            margin-top:5px;
          }`
        }
    },
    index_tabs(){
        let titles = {
            tag:'div',
            for:'shop_list',
            'v-key':'{{index}}',
            text:'{{value.title}}',
            class:{this:'index == shop_list_index'},
            css:`{lcpid}{
                color:#eee;
                display:flex;
                align-items:center;
                cursor:pointer;
                position:relative;
                font-size:15px;
            }
            {lcpid}:hover{
                opacity:.9;
            }
            {lcpid}.this::after{
                content:'';
                display:block;
                height:2px;
                background-color:#1e9fff;
                width:100%;
                position:absolute;
                bottom:0;
                border-radius:5px;
            }`,
            onclick(e){
                let index = e.target.getAttribute('v-key');
                let forbear = this.forbear();
                let data = forbear.data;
                data.shop_list_index = index;
            }
        }
        let title = {
            tag:'div',
            css:`{lcpid}{
                height:60px;
                display:flex;
                justify-content:space-evenly;
                flex-shrink:0;
            }`,
            children:[
                titles
            ]
        }
        let one = {
            tag:'div',
            for:'shop_list',
            style:{
            },
            children:[
                this.shop_list_one()
            ]
        }
        
        let route = {
            tag:'div',
            style:{
                transform:'translateX({{-100 * shop_list_index}}%)'
            },
            css:`{lcpid}{
                height:100%;
                display:flex;
                transition:transform .3s;
            }
            {lcpid}>div{
                flex-shrink:0;
                height:100%;
                width:100%;
            }`,
            children:[
                one
            ]
        }
        let container = {
            tag:'div',
            css:`{lcpid}{
                flex-grow:1;
                margin:0 10px;
                margin-top:10px;
                overflow:hidden;
            }`,
            children:[
                route
            ]
        }
        return {
            tag:'div',
            css:`{lcpid}{
                display:flex;
                flex-direction:column;
                height:100%;
            }`,
            children:[
                title,
                container
            ]
        }
    },
    shop_list_one(){
        let title = {
            tag:'div',
            children:[
                {tag:'span',text:'{{++index}}'},
                {tag:'span',text:'{{value.title}}'}
            ]
        }
        let number = {
            tag:'div',
            text:'{{test(value.number)}}'
        }
        let box = {
            tag:'div',
            for:'value.list',
            children:[
                title,number
            ]
        }
        return {
            tag:'div',
            css:`{lcpid}{
                overflow-y:auto;
                padding:0 15px;
                height:100%;
            }
            {lcpid}>div{
                margin:10px 0;
                cursor:pointer;
            }
            {lcpid}>div>div:nth-child(1){
                display:flex;
                white-space:nowrap;
                overflow:hidden;
                text-overflow:ellipsis;
            }
            {lcpid}>div>div:nth-child(1)>span:nth-child(1){
                color:#ffffff80;
                font-size:15px;
            }
            {lcpid}>div>div:nth-child(1)>span:nth-child(2){
                color:#ffffffe6;
                margin-left:10px;
                font-size:15px;
            }
            {lcpid}>div>div:nth-child(1)>span:nth-child(2):hover{
                color:#fff;
            }
            {lcpid}>div>div:nth-child(2){
                color:#FFFFFF80;
                margin-top:8px;
                padding-left:20px;
            }`,
            children:[
                box
            ]
        }
    }

}