const index = function(){
   let commodity = ui.commodity();
   commodity.style = {
      margin:'8px'
   }
   commodity.for = 'commodity_list';
   let left = {
      tag:'div',
      css:`{lcpid}{
         flex-grow:1;
         display:flex;
         margin-right:5px;
         flex-wrap:wrap;
         align-content:flex-start;
         overflow-y:auto;
         padding-bottom:10px;
      }`,
      children:[
         commodity
      ]
   }
   let right = {
      tag:'div',
      css:`{lcpid}{
         width:325px;
         flex-shrink:0;
         background-color:var(--commodity_color);
         margin-top:8px;
         border-radius:10px;
         padding-bottom:10px;
      }`,
      children:[
         ui.index_tabs()
      ]
   }
   return {
      tag:'div',
      css:`{lcpid}{
         display:flex;
         width:100%;
      }`,
      children:[
         left,right
      ]
   }
}