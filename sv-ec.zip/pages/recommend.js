let recommend = function(){
    let video = {
        tag:'video',
        src:'./images/cs.mp4',
        controls:true
    }
    let box = {
        tag:'div',
        css:`{lcpid}{
            width:calc(100% - 100px);
            background-color:rgba(65,65,65,0.6);
            backdrop-filter:blur(22px);
            border-radius:20px;
            height:calc(100% - 20px);
            margin-right:40px;
            overflow:hidden;
        }
        {lcpid}>video{
            width:100%;
            height:100%;
        }`,
        children:[
            video
        ]
    }
    let listbox = {
        tag:'div',
        css:`{lcpid}{
            position:relative;
            width:100%;
            height:100%;
            flex-shrink:0;
        }
        `,
        children:[
            box,
        ]
    }
    let list = {
        tag:'div',
        css:`{lcpid}{
            width:100%;
            height:100%;
            display:flex;
            flex-direction:column;
            overflow-y:auto;
        }`,
        children:[
            listbox,listbox
        ]
    }
    return {
        tag:'div',
        css:`{lcpid}{
            overflow:hidden;
        }
        `,
        children:[
            list
        ]
    }
}