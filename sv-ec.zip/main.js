const { createAPP } = lcp;
let svec_content = ui.svec_content();
let route = {
    tag:'div',
    style:{
        transform:'translateX({{-100 * nav_index}}%)'
    },
    css:`{lcpid}{
        height:100%;
        display:flex;
        transition:transform .3s;
    }
    {lcpid}>div{
        flex-shrink:0;
        width:100%;
        height:100%;
    }`,
    children:[
        index(),
        recommend(),
        index()
    ]
}
svec_content.children = [route];
let content = {
    tag:'div',
    css:`{lcpid}{
        height:calc(100% - 4.8rem);
        width:100%;
        display:flex;
    }`,
    children:[
        ui.svec_nav(),
        svec_content
    ]
}
let app = createAPP({
    el : '#app',
    data:{
      nav_list:[
         '首页','推荐','关注','朋友','我的'
      ],
      nav_index:0,
      commodity_list:[
        {src:'./images/tb/1.jpg.avif',text:'VVS美学灯风扇客厅灯吸顶灯具套餐led客厅大灯饰全屋中山灯具大全 【风扇款】三室两厅智能调光',anthor:'lcp',date:'2024/1/2',heart:1,duration:'00:09'},
        {src:'./images/tb/2.jpg.avif',text:'飞利浦（PHILIPS）小太阳超值型石英灯H7-12972PR汽车灯泡大灯近光灯远光灯卤素灯',anthor:'lcp',date:'2024/1/2',heart:100,duration:'00:06'},
        {src:'./images/tb/3.jpg.avif',text:'Haier海尔冰箱大容量净味保鲜风冷无霜一级能效变频节能超薄智能家用电冰箱 406升星石蓝',anthor:'lcp',date:'2024/1/2',heart:1068,duration:'00:22'},
        {src:'./images/tb/4.jpg.avif',text:'欧普照明（OPPLE） 安全灯暖多功能浴霸卫生间浴室适用 普通吊顶',anthor:'lcp',date:'2024/1/2',heart:156,duration:'00:13'},
        {src:'./images/tb/5.jpg.avif',text:'格力（GREE）云佩  新一级能效 智能生态变频冷暖 壁挂式卧室 挂机空调 1.5匹 KFR-35GW/NhAh1BAj',anthor:'lcp',date:'2024/1/2',heart:1754,duration:'01:09'},
        {src:'./images/tb/6.jpg.avif',text:'绿联 车载充电器 适用苹果15PD30W车充超级快充汽车点烟器一拖二',anthor:'lcp',date:'2024/1/2',heart:145,duration:'00:32'},
        {src:'./images/tb/7.jpg.avif',text:'海尔冰箱410升风冷无霜法式多门冰箱一级能效',anthor:'lcp',date:'2024/1/2',heart:234,duration:'00:45'},
        {src:'./images/tb/8.jpg.avif',text:'博世（BOSCH）机油滤芯机滤清器0047适配现代索纳塔伊兰特新胜达ix35起亚K2K5等',anthor:'lcp',date:'2024/1/2',heart:121,duration:'02:09'},
        {src:'./images/tb/9.jpg.avif',text:'美厨（maxcook）蒸锅 304不锈钢30CM三层蒸锅 加厚复底汤锅 燃气电磁炉通用MCZ827',anthor:'lcp',date:'2024/1/2',heart:146,duration:'00:27'},
        {src:'./images/tb/10.jpg.avif',text:'【￥10599元】西屋S570按摩椅',anthor:'lcp',date:'2024/1/2',heart:356,duration:'00:47'},
        {src:'./images/tb/11.jpg.avif',text:'九牧（JOMOO）不锈钢上水头编织软管花洒耐热防爆淋浴软管1.5米H2BE2-150103C-2',anthor:'lcp',date:'2024/1/2',heart:897,duration:'00:59'},
        {src:'./images/tb/12.jpg.avif',text:'隆晨2014陈年普洱茶生普 老班章普洱茶生茶礼盒 布朗山古树普洱茶散茶 2014年 散装 500克 * 1篓',anthor:'lcp',date:'2024/1/2',heart:14578,duration:'10:09'},
      ],
      shop_list:[
         {title:'销量榜',list:[
            {title:'2024年度最火电饭煲',number:1000000},
            {title:'山西果冻橙10斤装',number:990000},
            {title:'lcp短视频电商流量包',number:660000},
            {title:'lcp短视频电商平台分站',number:540000},
            {title:'隆晨2014陈年普洱茶生普 老班章普洱茶生茶礼盒 布朗山古树普洱茶散茶 2014年 散装 500克 * 1篓',number:500000},
            {title:'2024年度最火电饭煲',number:1000000},
            {title:'山西果冻橙10斤装',number:990000},
            {title:'lcp短视频电商流量包',number:660000},
            {title:'lcp短视频电商平台分站',number:540000},
            {title:'隆晨2014陈年普洱茶生普 老班章普洱茶生茶礼盒 布朗山古树普洱茶散茶 2014年 散装 500克 * 1篓',number:500000},
            {title:'2024年度最火电饭煲',number:1000000},
            {title:'山西果冻橙10斤装',number:990000},
            {title:'lcp短视频电商流量包',number:660000},
            {title:'lcp短视频电商平台分站',number:540000},
            {title:'隆晨2014陈年普洱茶生普 老班章普洱茶生茶礼盒 布朗山古树普洱茶散茶 2014年 散装 500克 * 1篓',number:500000},
            {title:'2024年度最火电饭煲',number:1000000},
            {title:'山西果冻橙10斤装',number:990000},
            {title:'lcp短视频电商流量包',number:660000},
            {title:'lcp短视频电商平台分站',number:540000},
            {title:'隆晨2014陈年普洱茶生普 老班章普洱茶生茶礼盒 布朗山古树普洱茶散茶 2014年 散装 500克 * 1篓',number:500000}
         ]},
         {title:'热搜榜',list:[
            {title:'2024年度最火电饭煲',number:1000000},
            {title:'山西果冻橙10斤装',number:990000},
            {title:'lcp短视频电商流量包',number:660000},
            {title:'lcp短视频电商平台分站',number:540000},
            {title:'隆晨2014陈年普洱茶生普 老班章普洱茶生茶礼盒 布朗山古树普洱茶散茶 2014年 散装 500克 * 1篓',number:500000}
         ]},
         {title:'店铺榜',list:[
            {title:'2024年度最火电饭煲',number:1000000},
            {title:'山西果冻橙10斤装',number:990000},
            {title:'lcp短视频电商流量包',number:660000},
            {title:'lcp短视频电商平台分站',number:540000},
            {title:'隆晨2014陈年普洱茶生普 老班章普洱茶生茶礼盒 布朗山古树普洱茶散茶 2014年 散装 500克 * 1篓',number:500000}
         ]},
         {title:'达人榜',list:[
            {title:'2024年度最火电饭煲',number:1000000},
            {title:'山西果冻橙10斤装',number:990000},
            {title:'lcp短视频电商流量包',number:660000},
            {title:'lcp短视频电商平台分站',number:540000},
            {title:'隆晨2014陈年普洱茶生普 老班章普洱茶生茶礼盒 布朗山古树普洱茶散茶 2014年 散装 500克 * 1篓',number:500000},
            {title:'2024年度最火电饭煲',number:1000000},
            {title:'山西果冻橙10斤装',number:990000},
            {title:'lcp短视频电商流量包',number:660000},
            {title:'lcp短视频电商平台分站',number:540000},
            {title:'隆晨2014陈年普洱茶生普 老班章普洱茶生茶礼盒 布朗山古树普洱茶散茶 2014年 散装 500克 * 1篓',number:500000},
            {title:'2024年度最火电饭煲',number:1000000},
            {title:'山西果冻橙10斤装',number:990000},
            {title:'lcp短视频电商流量包',number:660000},
            {title:'lcp短视频电商平台分站',number:540000},
            {title:'隆晨2014陈年普洱茶生普 老班章普洱茶生茶礼盒 布朗山古树普洱茶散茶 2014年 散装 500克 * 1篓',number:500000},
            {title:'2024年度最火电饭煲',number:1000000},
            {title:'山西果冻橙10斤装',number:990000},
            {title:'lcp短视频电商流量包',number:660000},
            {title:'lcp短视频电商平台分站',number:540000},
            {title:'隆晨2014陈年普洱茶生普 老班章普洱茶生茶礼盒 布朗山古树普洱茶散茶 2014年 散装 500克 * 1篓',number:500000}
         ]}
      ],
      shop_list_index:0,
      test(num){
          if(num > 10000){
             return num / 10000 + 'w';
          }else{
            return num;
          }
      }
    },
    children:[
        ui.svec_head(),
        content
    ]
});